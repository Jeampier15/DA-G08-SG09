const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');

const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',        // Cambia esto según tu configuración de MySQL
    password: '',        // Si tienes contraseña para MySQL
    database: 'barbershop'
  });
  
  db.connect((err) => {
    if (err) {
      console.error('Error de conexión a la base de datos:', err);
      return;
    }
    console.log('Conexión exitosa a la base de datos');
  });

  app.get('/books', (req, res) => {
    db.query('SELECT * FROM books', (err, results) => {
      if (err) {
        res.status(500).send('Error al consultar la base de datos');
        return;
      }
      res.json(results);
    });
  });
  
//API
  app.get('/books/:id', function(req, res) {
    connection.query('select * from books where id=?', [req.params.id], function(error, results) {
      if (error) throw error;
      res.end(JSON.stringify(results));
    });
  });



  const app = express();
app.use(bodyParser.json());  // Para poder recibir JSON en las solicitudes

app.listen(3000, () => {
  console.log('Servidor corriendo en el puerto 3000');
});


