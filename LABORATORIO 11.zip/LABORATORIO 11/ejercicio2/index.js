const express = require('express');
const jwt = require('jsonwebtoken');
const app = express();

// Clave secreta directamente en el código (en vez de .env)
const JWT_SECRET = 'mi_clave_secreta';  // Cambia esto por una clave segura en producción

// Middleware para verificar el token
function verifiToken(req, res, next) {
    const bearerHeader = req.headers['authorization'];

    if (typeof bearerHeader === 'undefined') {
        return res.sendStatus(403); // Token no proporcionado
    }

    const bearer = bearerHeader.split(' ');
    const bearerToken = bearer[1];

    req.token = bearerToken; // Almacenamos el token en el objeto request

    // Verificar el token usando jwt.verify
    jwt.verify(bearerToken, JWT_SECRET, (err, decoded) => {
        if (err) {
            return res.sendStatus(403); // Token inválido o expirado
        }
        req.user = decoded; // Decodificamos el payload del token
        next(); // Continuamos con la solicitud
    });
}

// Ruta pública: Login (generación de token)
app.post('/api/login', (req, res) => {
    const user = {
        id: 1,
        username: "jeampier",  // Nombre de usuario actualizado
        email: "jeampier@gmail.com"  // Email actualizado
    };

    // Generación del token con el usuario actualizado
    jwt.sign(user, JWT_SECRET, { expiresIn: '1h' }, (err, token) => {
        if (err) {
            return res.status(500).json({ mensaje: 'Error al generar el token' });
        }
        res.json({
            token
        });
    });
});

// Ruta protegida: Información de clientes
app.get('/api/protected', verifiToken, (req, res) => {
    res.json({
        mensaje: "Acceso autorizado. Aquí está la información de los clientes.",
        usuario: req.user // Información del usuario decodificada del token
    });
});

// Ruta protegida: Información de un evento privado
app.get('/api/event', verifiToken, (req, res) => {
    // Información del evento privado (solo accesible con un JWT válido)
    const eventInfo = {
        evento: "Concierto de Rock",
        fecha: "2024-12-25",
        lugar: "Estadio Nacional",
        precio: "$50",
        descripcion: "Un concierto único con las mejores bandas de rock."
    };

    res.json({
        mensaje: "Acceso autorizado. Aquí está la información del evento.",
        evento: eventInfo,
        usuario: req.user // Información del usuario decodificada del token
    });
});

// Configuración para escuchar en el puerto 5000
app.listen(5000, () => console.log("Servidor ejecutándose en el puerto 5000"));
