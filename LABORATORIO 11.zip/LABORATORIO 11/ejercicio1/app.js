// app.js
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const bookRouter = require('./routes/books');  // Importamos las rutas de los libros

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());  // Para parsear cuerpos JSON de las peticiones

// Usamos las rutas definidas para el API
app.use('/api', bookRouter);

// Configuración del puerto y ejecución del servidor
const port = 3000;
app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});
