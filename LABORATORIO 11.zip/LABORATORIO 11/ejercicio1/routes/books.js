

const express = require('express');
const appRouter = express.Router();
const con = require('../config/connection');  // Conexión a la base de datos
const bodyParser = require('body-parser');

// Middleware para parsear el cuerpo de las peticiones
appRouter.use(bodyParser.urlencoded({ extended: true }));
appRouter.use(bodyParser.json());

// Consultas para la base de datos
let sql_all = "CALL usp_listar_cars()";  // Consulta para listar los carros
let sql_insert = "CALL usp_insertar_car(?, ?, ?)";  // Procedimiento para insertar un nuevo carro
let sql_update = "CALL usp_actualizar_car(?, ?, ?, ?)";  // Procedimiento para actualizar un carro
let sql_delete = "CALL usp_eliminar_car(?)";  // Procedimiento para eliminar un carro por id

// Ruta para listar todos los carros
appRouter.get('/cars', (req, res) => {
    con.query(sql_all, (error, results) => {
        if (error) {
            console.error('Error al obtener los carros:', error);
            res.status(500).json({ error: 'Error al obtener los carros' });
        } else {
            res.status(200).json(results[0]);  // Los resultados de la consulta vienen en el primer array
        }
    });
});

// Ruta para agregar un nuevo carro
appRouter.post('/cars', (req, res) => {
    const car = {
        brand: req.body.car_brand,
        model_id: req.body.car_model_id,
        year: req.body.car_year
    };

    con.query(sql_insert, [car.brand, car.model_id, car.year], (error, results) => {
        if (error) {
            console.error('Error al insertar el carro:', error);
            res.status(500).json({ error: 'Error al insertar el carro' });
        } else {
            res.status(201).json({
                message: 'Carro agregado exitosamente',
                carId: results[0].id  // El ID del carro insertado
            });
        }
    });
});

// Ruta para actualizar un carro
appRouter.put('/cars/:id', (req, res) => {
    const carId = req.params.id;
    const updatedCar = {
        brand: req.body.car_brand,
        model_id: req.body.car_model_id,
        year: req.body.car_year
    };

    con.query(sql_update, [carId, updatedCar.brand, updatedCar.model_id, updatedCar.year], (error, results) => {
        if (error) {
            console.error('Error al actualizar el carro:', error);
            res.status(500).json({ error: 'Error al actualizar el carro' });
        } else {
            res.status(200).json({
                message: 'Carro actualizado exitosamente',
                updatedCarId: carId
            });
        }
    });
});

// Ruta para eliminar un carro
appRouter.delete('/cars/:id', (req, res) => {
    const carId = req.params.id;

    con.query(sql_delete, [carId], (error, results) => {
        if (error) {
            console.error('Error al eliminar el carro:', error);
            res.status(500).json({ error: 'Error al eliminar el carro' });
        } else {
            res.status(200).json({
                message: `Carro con ID ${carId} eliminado exitosamente`
            });
        }
    });
});

module.exports = appRouter;



//:model_name