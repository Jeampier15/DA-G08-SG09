// routes/books.js
const express = require('express');
const appRouter = express.Router();
const con = require('../config/connection');  // Conexión a la base de datos
const bodyParser = require('body-parser');

// Middleware para parsear el cuerpo de las peticiones
appRouter.use(bodyParser.urlencoded({ extended: true }));
appRouter.use(bodyParser.json());

// Definir la consulta para listar los libros (procedimiento almacenado)
let sql_all = "CALL usp_listar_books()";  // Esto lista los libros

// Definir la consulta para insertar un nuevo libro (procedimiento almacenado)
let sql_insert = "CALL usp_insertar_book(?, ?, ?)";  // Asumiendo que este es el procedimiento para insertar un libro

// Ruta para listar todos los libros
appRouter.get('/books', (req, res) => {
    con.query(sql_all, (error, results) => {
        if (error) {
            console.error('Error al obtener los libros:', error);
            res.status(500).json({ error: 'Error al obtener los libros' });
        } else {
            res.status(200).json(results);
        }
    });
});

// Ruta para agregar un nuevo libro
appRouter.post('/books', (req, res) => {
    const book = {
        title: req.body.book_title,
        author: req.body.book_author,
        publicado: req.body.book_published
    };

    // Ejecutamos el procedimiento almacenado para insertar un libro
    con.query(sql_insert, [book.title, book.author, book.publicado], (error, results) => {
        if (error) {
            console.error('Error al insertar el libro:', error);
            res.status(500).json({ error: 'Error al insertar el libro' });
        } else {
            res.status(201).json({
                message: 'Libro agregado exitosamente',
                bookId: results[0].id  // Suponiendo que el procedimiento devuelve el id del libro insertado
            });
        }
    });
});

module.exports = appRouter;

