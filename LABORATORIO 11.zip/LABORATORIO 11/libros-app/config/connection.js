// connection.js
const mysql = require('mysql');

const con = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',  // Si tienes contraseña, reemplázala aquí
  database: 'biblioteca'
});

con.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    throw err;
  }
  console.log('Conectado a la base de datos!');
});

module.exports = con;
