var express = require('express');
var app = express();
var connectDB = require('./models/db'); // Importamos la conexión a la DB
var Router = require('./controllers/routes');  // Correcto, sin 'app'
var port = 3000;

// Conexión a la base de datos
connectDB();

// Uso de las rutas
app.use('/api', Router);

// Arrancamos el servidor en el puerto 3000
app.listen(port, () => {
  console.log(`Servidor ejecutándose en el puerto ${port}`);
});
