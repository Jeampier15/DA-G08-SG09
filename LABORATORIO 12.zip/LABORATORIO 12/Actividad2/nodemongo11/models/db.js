// models/db.js
const mongoose = require('mongoose');

const MONGODB_URI = 'mongodb://localhost:27017/node-crud';  // Cambia esto si tu base de datos está en otro lugar.

const connectDB = async () => {
  try {
    await mongoose.connect(MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('Conexión exitosa a MongoDB');
  } catch (error) {
    console.error('Error al conectar a MongoDB:', error);
    process.exit(1); // Termina el proceso si la conexión falla
  }
};

module.exports = connectDB;
