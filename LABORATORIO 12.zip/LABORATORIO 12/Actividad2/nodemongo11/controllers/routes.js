var express = require('express');
var bodyParser = require('body-parser');
var Product = require('../models/products');
var router = express.Router();

// Configurando el Parser
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

// Middleware de logging
router.use(function (req, res, next) {
  console.log("Request received");
  next();
});

// Rutas para manejar productos
router.route('/products')
  .post(async function (req, res) {
    try {
      const product = new Product(req.body); // Crea un nuevo producto con los datos del cuerpo de la solicitud
      const savedProduct = await product.save(); // Guarda el producto en la base de datos
      res.status(201).json(savedProduct); // Envia la respuesta con el producto guardado
    } catch (error) {
      res.status(500).send("Error al guardar el producto: " + error);
    }
  })
  .get(async function (req, res) {
    try {
      const products = await Product.find(); // Obtiene todos los productos de la base de datos
      res.json(products); // Envia la respuesta con los productos
    } catch (error) {
      res.status(500).send("Error en el servicio: " + error);
    }
  });

module.exports = router;
