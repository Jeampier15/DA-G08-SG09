const express = require('express');
const app = express();
const connectDB = require('./db');
const router = require('./controllers/routes');
const port = 3000;

// Conectar a la base de datos
connectDB();

// Usar las rutas definidas
app.use('/api', router);

// Levantar el servidor
app.listen(port, () => {
  console.log(`Servidor ejecutándose en el puerto ${port}`);
});
