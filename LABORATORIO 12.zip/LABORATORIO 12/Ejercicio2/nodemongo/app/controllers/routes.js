const express = require('express');
const bodyParser = require('body-parser');
const Product = require('../models/products');
const router = express.Router();

// Configuración del body-parser
router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

// Middleware de logging
router.use(function (req, res, next) {
  console.log(`${req.method} request made to: ${req.url}`);
  next();
});

// POST: Crear un nuevo producto
router.post('/products', async (req, res) => {
  try {
    const product = new Product(req.body); // Crear el producto con los datos proporcionados
    const savedProduct = await product.save(); // Guardar el producto
    res.status(201).json(savedProduct); // Responder con el producto creado
  } catch (error) {
    res.status(500).send("Error al guardar el producto: " + error);
  }
});

// GET: Obtener todos los productos
router.get('/products', async (req, res) => {
  try {
    const products = await Product.find(); // Buscar todos los productos
    res.json(products); // Responder con los productos encontrados
  } catch (error) {
    res.status(500).send("Error en el servicio: " + error);
  }
});

// GET: Obtener un producto por ID
router.get('/products/:id', async (req, res) => {
  try {
    const product = await Product.findById(req.params.id); // Buscar producto por ID
    if (!product) {
      return res.status(404).send("Producto no encontrado");
    }
    res.json(product); // Responder con el producto encontrado
  } catch (error) {
    res.status(500).send("Error al obtener el producto: " + error);
  }
});

// PUT: Actualizar un producto por ID
router.put('/products/:id', async (req, res) => {
  try {
    const updatedProduct = await Product.findByIdAndUpdate(
      req.params.id, // Buscar por ID
      req.body, // Datos a actualizar
      { new: true } // Devolver el documento actualizado
    );
    if (!updatedProduct) {
      return res.status(404).send("Producto no encontrado");
    }
    res.json(updatedProduct); // Responder con el producto actualizado
  } catch (error) {
    res.status(500).send("Error al actualizar el producto: " + error);
  }
});

// DELETE: Eliminar un producto por nombre
router.delete('/products/:name', async (req, res) => {
  try {
    const deletedProduct = await Product.findOneAndDelete({ name: req.params.name }); // Eliminar por nombre
    if (!deletedProduct) {
      return res.status(404).send("Producto no encontrado");
    }
    res.json({ message: "Producto eliminado correctamente" }); // Responder con mensaje de éxito
  } catch (error) {
    res.status(500).send("Error al eliminar el producto: " + error);
  }
});

module.exports = router;
