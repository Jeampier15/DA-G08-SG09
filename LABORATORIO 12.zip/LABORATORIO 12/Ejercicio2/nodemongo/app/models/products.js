var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// Definición del esquema para un producto
var ProductSchema = new Schema({
  name: { type: String, required: true },
  amount: { type: Number, required: true },
  description: { type: String, required: true },
});

// Exportar el modelo
module.exports = mongoose.model('Product', ProductSchema);
